@echo off
REM Build on any Windows dev machine (needs Python 3.10+). Output: dist\BinSlide.exe
python -m venv .venv || exit /b 1
call .venv\Scripts\activate.bat
python -m pip install -r requirements.txt || exit /b 1
pyinstaller --clean --noconfirm BinSlide.spec || exit /b 1
echo.
echo Built dist\BinSlide.exe - copy that single file to the USB stick.
