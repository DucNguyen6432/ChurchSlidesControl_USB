# PyInstaller spec: ONE self-contained BinSlide.exe (bundles Python + Qt + python-pptx).
# The host PC needs nothing installed.
import os
from PyInstaller.utils.hooks import collect_submodules

hidden = collect_submodules("pptx") + ["PIL._imaging", "lxml._elementpath"]
excludes = [
    "PySide6.QtWebEngineCore", "PySide6.QtWebEngineWidgets", "PySide6.QtQml", "PySide6.QtQuick",
    "PySide6.QtMultimedia", "PySide6.Qt3DCore", "PySide6.QtCharts", "PySide6.QtPdf",
    "PySide6.QtSql", "PySide6.QtNetwork", "PySide6.QtBluetooth", "PySide6.QtSvg",
    "tkinter", "unittest", "pydoc", "xmlrpc", "numpy",
]

a = Analysis(["run_binslide.py"], pathex=["."], datas=[("binslide.marker", ".")] + ([("bundled_fonts", "bundled_fonts")] if os.path.isdir("bundled_fonts") else []),
             hiddenimports=hidden, excludes=excludes, noarchive=False)
pyz = PYZ(a.pure)
exe = EXE(pyz, a.scripts, a.binaries, a.datas, [],
          name="BinSlide", console=False, upx=False, runtime_tmpdir=None,
          disable_windowed_traceback=True)
