import sys
from binslide.app import main

if __name__ == "__main__":
    sys.exit(main())
