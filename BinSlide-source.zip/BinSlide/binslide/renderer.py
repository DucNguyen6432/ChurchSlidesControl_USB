"""
BinSlide native renderer: .pptx -> QImage, entirely in RAM.

python-pptx parses the package; shapes are painted with QPainter / QTextLayout.
Coordinate system while painting: 1 pt == ox.U (8) units, so slide space is
(slide_width_pt * 8) x (slide_height_pt * 8) and the painter is scaled to pixels.
"""
from __future__ import annotations

import io
import math
import threading
from collections import OrderedDict, deque

from PySide6.QtCore import Qt, QPointF, QRectF
from PySide6.QtGui import (
    QBrush, QColor, QFont, QFontDatabase, QImage, QLinearGradient, QPainter, QPainterPath,
    QPen, QPolygonF, QRadialGradient, QTextCharFormat, QTextLayout, QTextOption, QTransform,
)

from . import ooxml as ox
from .ooxml import A, NS, P, R_NS, EMU_TO_U, U

K = EMU_TO_U  # EMU -> painter units
MAX_IMAGE_PX = 3840
DEFAULT_PT = 18.0

# Fonts commonly used in decks but absent on a stock Windows PC -> closest installed look-alike.
FONT_FALLBACKS = {
    "helvetica neue": "Arial", "helvetica": "Arial", "times": "Times New Roman",
    "calibri light": "Calibri", "segoe ui light": "Segoe UI", "segoe ui semilight": "Segoe UI",
    "arial narrow": "Arial", "avenir": "Segoe UI", "avenir next": "Segoe UI",
    "gill sans": "Segoe UI", "gill sans mt": "Segoe UI", "optima": "Segoe UI",
    "garamond": "Georgia", "palatino": "Georgia", "palatino linotype": "Georgia",
    "book antiqua": "Georgia", "baskerville": "Georgia", "cambria math": "Cambria",
}

_PLACEHOLDER_TITLE = {"TITLE", "CENTER_TITLE", "VERTICAL_TITLE"}
_PLACEHOLDER_OTHER = {"DATE", "FOOTER", "SLIDE_NUMBER", "HEADER"}


def _bool(v) -> bool:
    return v in ("1", "true")


def _ph_kind(ph_shape) -> str:
    """'title' | 'other' | 'body' for a placeholder shape."""
    try:
        name = ph_shape.placeholder_format.type.name
    except Exception:
        return "body"
    if name in _PLACEHOLDER_TITLE:
        return "title"
    if name in _PLACEHOLDER_OTHER:
        return "other"
    return "body"


class Ctx:
    """Everything needed to resolve references while painting one scope
    (a slide, its layout, or its master)."""
    __slots__ = ("theme", "part", "index", "layout", "master")

    def __init__(self, theme, part, index, layout, master):
        self.theme, self.part, self.index = theme, part, index
        self.layout, self.master = layout, master


# ----------------------------------------------------------------------
# Deck: parsed presentation + painting
# ----------------------------------------------------------------------
class Deck:
    def __init__(self, data: bytes):
        from pptx import Presentation
        self.prs = Presentation(io.BytesIO(data))
        self.slides = list(self.prs.slides)
        self.w = self.prs.slide_width * K
        self.h = self.prs.slide_height * K
        self.aspect = self.prs.slide_width / float(self.prs.slide_height)
        self.default_text = self.prs._element.find(P("defaultTextStyle"))
        self._themes: dict = {}
        self._images: OrderedDict = OrderedDict()
        self._lock = threading.RLock()
        self.errors: dict = {}      # slide index -> [messages] for shapes that failed to draw
        self._fam_cache: dict = {}
        self.warnings = self._scan()

    @property
    def count(self) -> int:
        return len(self.slides)

    # -- analysis ---------------------------------------------------------
    def _scan(self) -> dict:
        """slide number -> set of unsupported element kinds."""
        out: dict = {}
        for i, s in enumerate(self.slides):
            kinds = set()
            for gd in s._element.iter(A("graphicData")):
                uri = gd.get("uri", "")
                if uri.endswith("/chart"):
                    kinds.add("chart")
                elif uri.endswith("/diagram"):
                    kinds.add("SmartArt")
                elif not uri.endswith("/table"):
                    kinds.add("embedded object")
            if kinds:
                out[i + 1] = kinds
        return out

    # -- fonts ---------------------------------------------------------------
    def font_report(self) -> list:
        """Typefaces the deck asks for that this PC does not have (needs a QGuiApplication)."""
        used = set()
        parts = [self.prs._element]
        for s in self.slides:
            parts.append(s._element)
            parts.append(s.slide_layout._element)
            parts.append(s.slide_layout.slide_master._element)
        for m in {id(x.slide_layout.slide_master): x.slide_layout.slide_master for x in self.slides}.values():
            th = self.theme_for(m)
            used.update((th.major_font, th.minor_font))
        for root in parts:
            for lat in root.iter(A("latin")):
                tf = lat.get("typeface")
                if tf and not tf.startswith("+"):
                    used.add(tf)
        return sorted(f for f in used if f and not QFontDatabase.hasFamily(f)
                      and not (FONT_FALLBACKS.get(f.lower()) and QFontDatabase.hasFamily(FONT_FALLBACKS[f.lower()])))

    def _fam(self, name):
        """Installed family to use for ``name``: itself, a look-alike, or Arial (stable metrics)."""
        key = name or ""
        r = self._fam_cache.get(key)
        if r is None:
            if key and QFontDatabase.hasFamily(key):
                r = key
            else:
                alt = FONT_FALLBACKS.get(key.lower())
                if alt and QFontDatabase.hasFamily(alt):
                    r = alt
                elif QFontDatabase.hasFamily("Arial"):
                    r = "Arial"
                else:
                    r = key
            self._fam_cache[key] = r
        return r

    # -- theme -------------------------------------------------------------
    def theme_for(self, master) -> ox.Theme:
        key = str(master.part.partname)
        th = self._themes.get(key)
        if th is None:
            from lxml import etree
            from pptx.opc.constants import RELATIONSHIP_TYPE as RT
            root = None
            try:
                root = etree.fromstring(master.part.part_related_by(RT.THEME).blob)
            except Exception:
                pass
            cm = master._element.find(P("clrMap"))
            th = ox.Theme(root, dict(cm.attrib) if cm is not None else {})
            self._themes[key] = th
        return th

    # -- images ------------------------------------------------------------
    def image(self, part, rid):
        key = (str(part.partname), rid)
        if key in self._images:
            self._images.move_to_end(key)
            return self._images[key]
        img = None
        try:
            blob = part.related_part(rid).blob
            img = QImage.fromData(blob)
            if img.isNull():
                from PIL import Image
                pil = Image.open(io.BytesIO(blob)).convert("RGBA")
                img = QImage(pil.tobytes("raw", "RGBA"), pil.width, pil.height,
                             pil.width * 4, QImage.Format.Format_RGBA8888).copy()
            if max(img.width(), img.height()) > MAX_IMAGE_PX:
                img = img.scaled(MAX_IMAGE_PX, MAX_IMAGE_PX, Qt.AspectRatioMode.KeepAspectRatio,
                                 Qt.TransformationMode.SmoothTransformation)
        except Exception:
            img = None
        self._images[key] = img
        while len(self._images) > 24:
            self._images.popitem(last=False)
        return img

    # -- placeholders / inheritance ---------------------------------------
    @staticmethod
    def layout_ph(layout, ph):
        if layout is None:
            return None
        try:
            pf = ph.placeholder_format
            for s in layout.placeholders:
                if s.placeholder_format.idx == pf.idx:
                    return s
            for s in layout.placeholders:
                if s.placeholder_format.type == pf.type:
                    return s
        except Exception:
            pass
        return None

    @staticmethod
    def master_ph(master, kind, ph_type):
        if master is None:
            return None
        try:
            for s in master.placeholders:
                if kind == "other":
                    if s.placeholder_format.type == ph_type:
                        return s
                elif _ph_kind(s) == kind:
                    return s
        except Exception:
            pass
        return None

    def text_chains(self, shape, ctx):
        """(text style chain, bodyPr chain) for a shape, highest priority first."""
        el = shape._element
        txb = el.find(P("txBody"))
        chain, body = [], []
        if txb is not None:
            chain.append(txb.find(A("lstStyle")))
            body.append(txb.find(A("bodyPr")))
        if getattr(shape, "is_placeholder", False) and ctx.master is not None:
            kind = _ph_kind(shape)
            lph = self.layout_ph(ctx.layout, shape)
            mph = self.master_ph(ctx.master, kind, shape.placeholder_format.type)
            for src in (lph, mph):
                if src is not None:
                    t = src._element.find(P("txBody"))
                    if t is not None:
                        chain.append(t.find(A("lstStyle")))
                        body.append(t.find(A("bodyPr")))
            key = {"title": "titleStyle", "body": "bodyStyle", "other": "otherStyle"}[kind]
            tx = ctx.master._element.find(P("txStyles"))
            if tx is not None:
                chain.append(tx.find(P(key)))
        chain.append(self.default_text)
        return [c for c in chain if c is not None], [b for b in body if b is not None]

    # -- rendering entry ----------------------------------------------------
    def render(self, index: int, width_px: int) -> QImage:
        with self._lock:
            self.errors.pop(index, None)
            w = max(2, int(width_px))
            h = max(2, int(round(w / self.aspect)))
            img = QImage(w, h, QImage.Format.Format_RGB32)
            img.fill(QColor(255, 255, 255))
            p = QPainter(img)
            try:
                p.setRenderHints(QPainter.RenderHint.Antialiasing
                                 | QPainter.RenderHint.TextAntialiasing
                                 | QPainter.RenderHint.SmoothPixmapTransform)
                p.scale(w / self.w, h / self.h)
                self._render_slide(p, index)
            finally:
                p.end()
            return img

    def _render_slide(self, p, index):
        slide = self.slides[index]
        layout = slide.slide_layout
        master = layout.slide_master
        theme = self.theme_for(master)
        s_ctx = Ctx(theme, slide.part, index, layout, master)
        l_ctx = Ctx(theme, layout.part, index, layout, master)
        m_ctx = Ctx(theme, master.part, index, layout, master)

        self._draw_background(p, [(slide, s_ctx), (layout, l_ctx), (master, m_ctx)])

        slide_flag = slide._element.get("showMasterSp") != "0"
        layout_flag = layout._element.get("showMasterSp") != "0"
        if slide_flag and layout_flag:
            self._draw_shapes(p, master.shapes, m_ctx, skip_ph=True)
        if slide_flag:
            self._draw_shapes(p, layout.shapes, l_ctx, skip_ph=True)
        self._draw_shapes(p, slide.shapes, s_ctx)

    # -- background -----------------------------------------------------------
    def _draw_background(self, p, scopes):
        full = QPainterPath()
        full.addRect(QRectF(0, 0, self.w, self.h))
        for obj, ctx in scopes:
            bg = obj._element.find("p:cSld/p:bg", NS)
            if bg is None:
                continue
            pr = bg.find(P("bgPr"))
            if pr is not None:
                for ch in pr:
                    if ox.local(ch.tag) in ("noFill", "solidFill", "gradFill", "blipFill", "pattFill"):
                        self._fill_path(p, full, ch, None, ctx, full.boundingRect())
                        return
                continue
            ref = bg.find(P("bgRef"))
            if ref is not None:
                style = ctx.theme.fill_style(int(ref.get("idx", "0")))
                if style is not None:
                    self._fill_path(p, full, style, ctx.theme.color_in(ref), ctx, full.boundingRect())
                    return

    # -- shape walker ----------------------------------------------------------
    def _draw_shapes(self, p, shapes, ctx, skip_ph=False):
        for sh in shapes:
            try:
                el = sh._element
                if skip_ph and getattr(sh, "is_placeholder", False):
                    continue
                c = el.find(".//p:cNvPr", NS)
                if c is not None and _bool(c.get("hidden")):
                    continue
                tag = ox.local(el.tag)
                if tag == "grpSp":
                    self._draw_group(p, sh, ctx, skip_ph)
                elif tag in ("sp", "cxnSp"):
                    self._draw_sp(p, sh, ctx)
                elif tag == "pic":
                    self._draw_pic(p, sh, ctx)
                elif tag == "graphicFrame":
                    self._draw_frame(p, sh, ctx)
            except Exception as exc:  # a broken shape must never take down the show
                self.errors.setdefault(ctx.index, []).append("%s: %s" % (type(exc).__name__, exc))
                continue

    @staticmethod
    def _xfrm(el):
        for path in ("p:spPr/a:xfrm", "p:grpSpPr/a:xfrm", "p:xfrm"):
            x = el.find(path, NS)
            if x is not None:
                return x
        return None

    def _box(self, sh):
        l, t, w, h = sh.left, sh.top, sh.width, sh.height
        if l is None or t is None or w is None or h is None:
            return None
        return l * K, t * K, w * K, h * K

    def _orient(self, el):
        x = self._xfrm(el)
        if x is None:
            return 0.0, False, False
        return (int(x.get("rot", "0")) / 60000.0, _bool(x.get("flipH")), _bool(x.get("flipV")))

    # -- groups -------------------------------------------------------------------
    def _draw_group(self, p, sh, ctx, skip_ph):
        el = sh._element
        xf = el.find("p:grpSpPr/a:xfrm", NS)
        if xf is None:
            return
        off, ext = xf.find(A("off")), xf.find(A("ext"))
        cho, che = xf.find(A("chOff")), xf.find(A("chExt"))
        x, y = int(off.get("x")) * K, int(off.get("y")) * K
        w, h = int(ext.get("cx")) * K, int(ext.get("cy")) * K
        rot, fh, fv = self._orient(el)
        p.save()
        p.translate(x + w / 2, y + h / 2)
        if rot:
            p.rotate(rot)
        p.scale(-1 if fh else 1, -1 if fv else 1)
        p.translate(-w / 2, -h / 2)
        if cho is not None and che is not None:
            cx, cy = int(cho.get("x")) * K, int(cho.get("y")) * K
            cw, ch = int(che.get("cx")) * K, int(che.get("cy")) * K
            if cw and ch:
                p.scale(w / cw, h / ch)
                p.translate(-cx, -cy)
        self._draw_shapes(p, sh.shapes, ctx, skip_ph)
        p.restore()

    # -- autoshapes / text boxes / connectors ------------------------------------------
    def _draw_sp(self, p, sh, ctx):
        box = self._box(sh)
        if box is None:
            return
        x, y, w, h = box
        el = sh._element
        rot, fh, fv = self._orient(el)
        p.save()
        p.translate(x + w / 2, y + h / 2)
        if rot:
            p.rotate(rot)
        p.save()
        p.scale(-1 if fh else 1, -1 if fv else 1)
        p.translate(-w / 2, -h / 2)
        self._draw_geometry(p, el, w, h, ctx)
        p.restore()
        txb = el.find(P("txBody"))
        if txb is not None and "".join(txb.itertext()).strip():
            p.translate(-w / 2, -h / 2)
            chain, body = self.text_chains(sh, ctx)
            font_color = None
            st = el.find(P("style"))
            if st is not None:
                fr = st.find(A("fontRef"))
                if fr is not None:
                    font_color = ctx.theme.color_in(fr)
            if font_color is not None and not getattr(sh, "is_placeholder", False):
                # a shape style's fontRef colour beats presentation defaults
                pos = chain.index(self.default_text) if self.default_text in chain else len(chain)
                chain.insert(pos, ox.make_defrpr(color=font_color))
            self._draw_text(p, txb, w, h, ctx, chain, body)
        p.restore()

    def _draw_geometry(self, p, el, w, h, ctx):
        spPr = el.find(P("spPr"))
        paths = self._geometry(spPr, w, h)
        fill_el, fill_ph = self._resolve_fill(el, spPr, ctx)
        pen, head, tail = self._resolve_line(el, spPr, ctx)
        bbox = QRectF(0, 0, w, h)
        for path, fillable, strokable in paths:
            if fillable and fill_el is not None:
                self._fill_path(p, path, fill_el, fill_ph, ctx, bbox)
            if strokable and pen is not None:
                p.setPen(pen)
                p.setBrush(Qt.BrushStyle.NoBrush)
                p.drawPath(path)
        if pen is not None and (head or tail) and paths and not paths[0][1]:
            self._draw_arrows(p, paths[0][0], pen, head, tail)

    @staticmethod
    def _draw_arrows(p, path, pen, head, tail):
        n = path.elementCount()
        if n < 2:
            return
        pts = [QPointF(path.elementAt(i).x, path.elementAt(i).y) for i in range(n)]
        size = max(pen.widthF() * 3.5, 3.0 * U)

        def arrow(tip, frm):
            dx, dy = tip.x() - frm.x(), tip.y() - frm.y()
            d = math.hypot(dx, dy) or 1.0
            ux, uy = dx / d, dy / d
            base = QPointF(tip.x() - ux * size, tip.y() - uy * size)
            nx, ny = -uy * size / 2.2, ux * size / 2.2
            poly = QPolygonF([tip, QPointF(base.x() + nx, base.y() + ny),
                              QPointF(base.x() - nx, base.y() - ny)])
            p.setPen(Qt.PenStyle.NoPen)
            p.setBrush(QBrush(pen.color()))
            p.drawPolygon(poly)

        if tail:
            arrow(pts[-1], pts[-2])
        if head:
            arrow(pts[0], pts[1])

    # -- fills & lines ---------------------------------------------------------
    @staticmethod
    def _resolve_fill(el, spPr, ctx):
        if spPr is not None:
            for ch in spPr:
                if ox.local(ch.tag) in ("noFill", "solidFill", "gradFill", "blipFill", "pattFill"):
                    return ch, None
        st = el.find(P("style"))
        if st is not None:
            ref = st.find(A("fillRef"))
            if ref is not None:
                idx = int(ref.get("idx", "0"))
                if idx > 0:
                    return ctx.theme.fill_style(idx), ctx.theme.color_in(ref)
        return None, None

    def _resolve_line(self, el, spPr, ctx):
        ln = spPr.find(A("ln")) if spPr is not None else None
        base, ph = None, None
        st = el.find(P("style"))
        if st is not None:
            ref = st.find(A("lnRef"))
            if ref is not None:
                idx = int(ref.get("idx", "0"))
                if idx > 0:
                    base = ctx.theme.line_style(idx)
                    ph = ctx.theme.color_in(ref)
        if ln is None and base is None:
            return None, False, False
        width = fill_el = dash = cap = None
        head = tail = False
        for src in (ln, base):
            if src is None:
                continue
            if width is None and src.get("w") is not None:
                width = int(src.get("w"))
            if cap is None:
                cap = src.get("cap")
            if fill_el is None:
                for t in ("noFill", "solidFill", "gradFill", "pattFill"):
                    c = src.find(A(t))
                    if c is not None:
                        fill_el = c
                        break
            if dash is None:
                d = src.find(A("prstDash"))
                if d is not None:
                    dash = d.get("val")
            he, te = src.find(A("headEnd")), src.find(A("tailEnd"))
            if he is not None and he.get("type", "none") != "none":
                head = True
            if te is not None and te.get("type", "none") != "none":
                tail = True
        if fill_el is None or ox.local(fill_el.tag) == "noFill":
            return None, False, False
        t = ox.local(fill_el.tag)
        if t == "gradFill":
            gs = fill_el.find("a:gsLst/a:gs", NS)
            color = ctx.theme.color_in(gs, ph) if gs is not None else None
        elif t == "pattFill":
            color = ctx.theme.color_in(fill_el.find(A("fgClr")), ph)
        else:
            color = ctx.theme.color_in(fill_el, ph)
        if color is None:
            return None, False, False
        wpt = (width if width is not None else 9525) * K
        pen = QPen(QColor(*color))
        pen.setWidthF(max(wpt, 0.25 * U))
        pen.setJoinStyle(Qt.PenJoinStyle.RoundJoin)
        pen.setCapStyle({"rnd": Qt.PenCapStyle.RoundCap, "sq": Qt.PenCapStyle.SquareCap}
                        .get(cap, Qt.PenCapStyle.FlatCap))
        if dash and dash != "solid":
            pen.setStyle(Qt.PenStyle.DotLine if dash in ("dot", "sysDot", "sysDash")
                         else Qt.PenStyle.DashDotLine if dash in ("dashDot", "lgDashDot", "sysDashDot")
                         else Qt.PenStyle.DashLine)
        return pen, head, tail

    def _fill_path(self, p, path, fill_el, ph, ctx, bbox):
        t = ox.local(fill_el.tag)
        if t == "noFill":
            return
        if t == "solidFill":
            c = ctx.theme.color_in(fill_el, ph)
            if c:
                p.fillPath(path, QBrush(QColor(*c)))
        elif t == "pattFill":
            c = ctx.theme.color_in(fill_el.find(A("fgClr")), ph)
            if c:
                p.fillPath(path, QBrush(QColor(*c)))
        elif t == "gradFill":
            brush = self._gradient(fill_el, ph, ctx, bbox)
            if brush is not None:
                p.fillPath(path, brush)
        elif t == "blipFill":
            blip = fill_el.find(A("blip"))
            rid = blip.get("{%s}embed" % R_NS) if blip is not None else None
            img = self.image(ctx.part, rid) if rid else None
            if img is None:
                self.errors.setdefault(ctx.index, []).append("picture fill could not be loaded")
                return
            p.save()
            p.setClipPath(path, Qt.ClipOperation.IntersectClip)
            am = blip.find(A("alphaModFix"))
            if am is not None:
                p.setOpacity(int(am.get("amt", "100000")) / 100000.0)
            tile = fill_el.find(A("tile"))
            if tile is not None:  # 1 image px == 1/96 in, scaled by sx/sy
                sx = 9525 * K * int(tile.get("sx", "100000")) / 100000.0
                sy = 9525 * K * int(tile.get("sy", "100000")) / 100000.0
                brush = QBrush(img)
                tf = QTransform()
                tf.translate(bbox.x(), bbox.y())
                tf.scale(sx, sy)
                brush.setTransform(tf)
                p.fillPath(path, brush)
            else:
                self._blit(p, img, bbox, self._src_rect(fill_el, img))
            p.restore()

    @staticmethod
    def _src_rect(parent, img):
        sr = parent.find(A("srcRect"))
        l = t = r = b = 0.0
        if sr is not None:
            l, t, r, b = (int(sr.get(k, "0")) / 100000.0 for k in ("l", "t", "r", "b"))
        iw, ih = img.width(), img.height()
        return QRectF(iw * l, ih * t, max(1.0, iw * (1 - l - r)), max(1.0, ih * (1 - t - b)))

    @staticmethod
    def _blit(p, img, dest, src):
        """Draw ``src`` of ``img`` into ``dest``. When the picture is much larger than its
        on-screen size it is first box-filtered down to the exact device size, because Qt's
        direct bilinear downscale aliases (shimmering edges on photos and scanned slides)."""
        crop = src.toRect()
        sub = img if (crop.x() == 0 and crop.y() == 0 and crop.width() == img.width()
                      and crop.height() == img.height()) else img.copy(crop)
        tr = p.worldTransform().mapRect(dest)
        tw, th = max(1, int(round(tr.width()))), max(1, int(round(tr.height())))
        if sub.width() > tw * 1.25 or sub.height() > th * 1.25:
            sub = sub.scaled(tw, th, Qt.AspectRatioMode.IgnoreAspectRatio,
                             Qt.TransformationMode.SmoothTransformation)
        p.drawImage(dest, sub)

    @staticmethod
    def _gradient(g, ph, ctx, bbox):
        stops = []
        for gs in g.findall("a:gsLst/a:gs", NS):
            c = ctx.theme.color_in(gs, ph)
            if c:
                stops.append((int(gs.get("pos", "0")) / 100000.0, c))
        if not stops:
            return None
        if len(stops) == 1:
            return QBrush(QColor(*stops[0][1]))
        w, h = bbox.width(), bbox.height()
        path = g.find(A("path"))
        if path is not None:
            ftr = path.find(A("fillToRect"))
            cx = cy = 0.5
            if ftr is not None:
                l, t = int(ftr.get("l", "50000")), int(ftr.get("t", "50000"))
                r, b = int(ftr.get("r", "50000")), int(ftr.get("b", "50000"))
                cx, cy = (l + (100000 - r)) / 200000.0, (t + (100000 - b)) / 200000.0
            grad = QRadialGradient(QPointF(bbox.x() + w * cx, bbox.y() + h * cy), max(w, h) * 0.75)
        else:
            lin = g.find(A("lin"))
            ang = math.radians(int(lin.get("ang", "0")) / 60000.0) if lin is not None else 0.0
            dx, dy = math.cos(ang), math.sin(ang)
            half = (abs(w * dx) + abs(h * dy)) / 2.0
            c = bbox.center()
            grad = QLinearGradient(QPointF(c.x() - dx * half, c.y() - dy * half),
                                   QPointF(c.x() + dx * half, c.y() + dy * half))
        for pos, c in stops:
            grad.setColorAt(min(1.0, max(0.0, pos)), QColor(*c))
        return QBrush(grad)

    # -- geometry ---------------------------------------------------------------
    def _geometry(self, spPr, w, h):
        if spPr is not None:
            cust = spPr.find(A("custGeom"))
            if cust is not None:
                return self._cust_paths(cust, w, h)
            pg = spPr.find(A("prstGeom"))
        else:
            pg = None
        prst = pg.get("prst", "rect") if pg is not None else "rect"
        adj = {}
        if pg is not None:
            for gd in pg.findall("a:avLst/a:gd", NS):
                f = gd.get("fmla", "")
                if f.startswith("val "):
                    try:
                        adj[gd.get("name")] = int(f[4:])
                    except ValueError:
                        pass
        return _preset(prst, w, h, adj)

    @staticmethod
    def _cust_paths(cust, w, h):
        out = []
        for pth in cust.findall("a:pathLst/a:path", NS):
            pw, ph_ = int(pth.get("w", "0")), int(pth.get("h", "0"))
            sx = w / pw if pw else K
            sy = h / ph_ if ph_ else K
            path = QPainterPath()
            cur = QPointF(0, 0)

            def pt(e):
                return QPointF(int(e.get("x")) * sx, int(e.get("y")) * sy)

            for cmd in pth:
                t = ox.local(cmd.tag)
                pts = cmd.findall(A("pt"))
                if t == "moveTo":
                    cur = pt(pts[0])
                    path.moveTo(cur)
                elif t == "lnTo":
                    cur = pt(pts[0])
                    path.lineTo(cur)
                elif t == "cubicBezTo":
                    path.cubicTo(pt(pts[0]), pt(pts[1]), pt(pts[2]))
                    cur = pt(pts[2])
                elif t == "quadBezTo":
                    path.quadTo(pt(pts[0]), pt(pts[1]))
                    cur = pt(pts[1])
                elif t == "arcTo":
                    wr, hr = int(cmd.get("wR", "0")) * sx, int(cmd.get("hR", "0")) * sy
                    st, sw = int(cmd.get("stAng", "0")) / 60000.0, int(cmd.get("swAng", "0")) / 60000.0
                    if wr and hr:
                        a0 = math.radians(st)
                        cx, cy = cur.x() - wr * math.cos(a0), cur.y() - hr * math.sin(a0)
                        path.arcTo(QRectF(cx - wr, cy - hr, 2 * wr, 2 * hr), -st, -sw)
                        a1 = math.radians(st + sw)
                        cur = QPointF(cx + wr * math.cos(a1), cy + hr * math.sin(a1))
                elif t == "close":
                    path.closeSubpath()
            out.append((path, pth.get("fill", "norm") != "none",
                        pth.get("stroke", "1") not in ("0", "false")))
        return out

    # -- pictures -------------------------------------------------------------------
    def _draw_pic(self, p, sh, ctx):
        box = self._box(sh)
        if box is None:
            return
        x, y, w, h = box
        el = sh._element
        blip = el.find("p:blipFill/a:blip", NS)
        if blip is None:
            return
        rid = blip.get("{%s}embed" % R_NS)
        img = self.image(ctx.part, rid) if rid else None
        if img is None:
            self.errors.setdefault(ctx.index, []).append("a picture could not be loaded")
        rot, fh, fv = self._orient(el)
        spPr = el.find(P("spPr"))
        p.save()
        p.translate(x + w / 2, y + h / 2)
        if rot:
            p.rotate(rot)
        p.scale(-1 if fh else 1, -1 if fv else 1)
        p.translate(-w / 2, -h / 2)
        geo = self._geometry(spPr, w, h)
        if img is not None:
            src = self._src_rect(el.find(P("blipFill")), img)
            p.save()
            pg = spPr.find(A("prstGeom")) if spPr is not None else None
            shaped = (spPr is not None and spPr.find(A("custGeom")) is not None) or \
                     (pg is not None and pg.get("prst", "rect") != "rect")
            if shaped and geo:
                p.setClipPath(geo[0][0], Qt.ClipOperation.IntersectClip)
            am = blip.find(A("alphaModFix"))
            if am is not None:
                p.setOpacity(int(am.get("amt", "100000")) / 100000.0)
            self._blit(p, img, QRectF(0, 0, w, h), src)
            p.restore()
        pen, _, _ = self._resolve_line(el, spPr, ctx)
        if pen is not None:
            p.setPen(pen)
            p.setBrush(Qt.BrushStyle.NoBrush)
            for path, _f, strokable in geo:
                if strokable:
                    p.drawPath(path)
        p.restore()

    # -- graphic frames (tables; charts/SmartArt get a labelled box) -----------------------
    def _draw_frame(self, p, sh, ctx):
        box = self._box(sh)
        if box is None:
            return
        x, y, w, h = box
        gd = sh._element.find(".//a:graphicData", NS)
        if gd is None:
            return
        tbl = gd.find(A("tbl"))
        if tbl is not None:
            self._draw_table(p, tbl, x, y, ctx)
            return
        uri = gd.get("uri", "")
        label = "Chart" if uri.endswith("/chart") else "SmartArt" if uri.endswith("/diagram") else "Embedded object"
        p.save()
        pen = QPen(QColor(160, 160, 160))
        pen.setWidthF(1.0 * U)
        pen.setStyle(Qt.PenStyle.DashLine)
        p.setPen(pen)
        p.setBrush(QBrush(QColor(242, 242, 242)))
        p.drawRect(QRectF(x, y, w, h))
        f = QFont("Segoe UI")
        f.setPixelSize(int(14 * U))
        p.setFont(f)
        p.setPen(QColor(110, 110, 110))
        p.drawText(QRectF(x, y, w, h), Qt.AlignmentFlag.AlignCenter,
                   "%s (not rendered by BinSlide)" % label)
        p.restore()

    def _draw_table(self, p, tbl, x0, y0, ctx):
        cols = [int(g.get("w", "0")) * K for g in tbl.findall("a:tblGrid/a:gridCol", NS)]
        rows = tbl.findall(A("tr"))
        rh = [int(r.get("h", "0")) * K for r in rows]
        pr = tbl.find(A("tblPr"))
        first_row = pr is not None and _bool(pr.get("firstRow"))
        banded = pr is not None and _bool(pr.get("bandRow"))
        sid = (pr.findtext(A("tableStyleId")) or "") if pr is not None else ""
        mode = "none" if "2D5ABB26" in sid else "grid" if "5940675A" in sid else "medium"
        th = ctx.theme
        accent = th.scheme("accent1")
        for ri, tr in enumerate(rows):
            ci = 0
            for tc in tr.findall(A("tc")):
                if _bool(tc.get("hMerge")) or _bool(tc.get("vMerge")):
                    ci += 1
                    continue
                cs, rs = int(tc.get("gridSpan", "1")), int(tc.get("rowSpan", "1"))
                cx, cy = x0 + sum(cols[:ci]), y0 + sum(rh[:ri])
                cw, ch = sum(cols[ci:ci + cs]), sum(rh[ri:ri + rs])
                ci += cs
                rect = QRectF(cx, cy, cw, ch)
                tcPr = tc.find(A("tcPr"))
                header = first_row and ri == 0
                # fill
                fill_c = None
                if tcPr is not None:
                    for chd in tcPr:
                        t = ox.local(chd.tag)
                        if t == "noFill":
                            fill_c = False
                            break
                        if t in ("solidFill", "gradFill"):
                            if t == "gradFill":
                                gs = chd.find("a:gsLst/a:gs", NS)
                                fill_c = th.color_in(gs) if gs is not None else None
                            else:
                                fill_c = th.color_in(chd)
                            break
                if fill_c is None and mode == "medium":
                    if header:
                        fill_c = accent + (255,)
                    else:
                        k = 0.4 if (not banded or (ri - (1 if first_row else 0)) % 2 == 0) else 0.2
                        fill_c = tuple(int(c * k + 255 * (1 - k)) for c in accent) + (255,)
                if fill_c:
                    p.fillRect(rect, QBrush(QColor(*fill_c)))
                # borders
                for side, line in (("lnL", (cx, cy, cx, cy + ch)), ("lnR", (cx + cw, cy, cx + cw, cy + ch)),
                                   ("lnT", (cx, cy, cx + cw, cy)), ("lnB", (cx, cy + ch, cx + cw, cy + ch))):
                    ln = tcPr.find(A(side)) if tcPr is not None else None
                    pen = None
                    if ln is not None:
                        if ln.find(A("noFill")) is None:
                            c = th.color_in(ln.find(A("solidFill")))
                            if c:
                                pen = QPen(QColor(*c))
                                pen.setWidthF(max(int(ln.get("w", "12700")) * K, 0.5 * U))
                    elif mode == "medium":
                        pen = QPen(QColor(255, 255, 255))
                        pen.setWidthF(1.0 * U)
                    elif mode == "grid":
                        pen = QPen(QColor(0, 0, 0))
                        pen.setWidthF(1.0 * U)
                    if pen is not None:
                        p.setPen(pen)
                        p.drawLine(QPointF(line[0], line[1]), QPointF(line[2], line[3]))
                # text
                txb = tc.find(A("txBody"))
                if txb is not None and "".join(txb.itertext()).strip():
                    chain = [txb.find(A("lstStyle"))]
                    if mode == "medium" and header:
                        chain.append(ox.make_defrpr(bold=True, color=(255, 255, 255)))
                    chain.append(self.default_text)
                    chain = [c for c in chain if c is not None]
                    ins = {
                        "lIns": int(tcPr.get("marL", "91440")) if tcPr is not None else 91440,
                        "rIns": int(tcPr.get("marR", "91440")) if tcPr is not None else 91440,
                        "tIns": int(tcPr.get("marT", "45720")) if tcPr is not None else 45720,
                        "bIns": int(tcPr.get("marB", "45720")) if tcPr is not None else 45720,
                    }
                    anchor = tcPr.get("anchor", "t") if tcPr is not None else "t"
                    p.save()
                    p.translate(cx, cy)
                    self._draw_text(p, txb, cw, ch, ctx, chain, [], insets=ins, anchor=anchor)
                    p.restore()

    # -- text -----------------------------------------------------------------------------
    def _draw_text(self, p, txb, w, h, ctx, chain, body, insets=None, anchor=None):
        th = ctx.theme
        ins = insets or {}

        def inset(name, default):
            v = ins.get(name)
            if v is None:
                v = ox.first_attr(body, name)
            return (int(v) if v is not None else default) * K

        li, ri, ti, bi = inset("lIns", 91440), inset("rIns", 91440), inset("tIns", 45720), inset("bIns", 45720)
        anchor = anchor or ox.first_attr(body, "anchor") or "t"
        wrap = ox.first_attr(body, "wrap") != "none"
        vert = ox.first_attr(body, "vert")
        scale, lnred, shrink = 1.0, 0.0, False
        for b in body:
            na = b.find(A("normAutofit"))
            if na is not None:
                shrink = na.get("fontScale") is None  # no stored scale: fit it ourselves
                scale = int(na.get("fontScale", "100000")) / 100000.0
                lnred = int(na.get("lnSpcReduction", "0")) / 100000.0
                break

        p.save()
        if vert in ("vert270",):
            p.translate(0, h)
            p.rotate(-90)
            w, h = h, w
        elif vert in ("vert", "eaVert"):
            p.translate(w, 0)
            p.rotate(90)
            w, h = h, w
        avail_w, avail_h = max(1.0, w - li - ri), max(1.0, h - ti - bi)

        layouts, total = self._layout_paragraphs(txb, avail_w, ctx, chain, scale, lnred, wrap)
        if shrink and total > avail_h:
            while total > avail_h and scale > 0.4:
                scale -= 0.05
                layouts, total = self._layout_paragraphs(txb, avail_w, ctx, chain, scale, lnred, wrap)
        if anchor == "ctr":
            oy = ti + (avail_h - total) / 2.0
        elif anchor == "b":
            oy = ti + avail_h - total
        else:
            oy = ti
        p.translate(li, oy)
        for pl in layouts:
            pl["lay"].draw(p, QPointF(0, pl["y"]))
            bu = pl["bullet"]
            if bu is not None:
                p.setFont(bu["font"])
                p.setPen(QColor(*bu["color"]))
                p.drawText(QPointF(bu["x"], pl["y"] + bu["base"]), bu["text"])
        p.restore()

    def _layout_paragraphs(self, txb, avail_w, ctx, chain, scale, lnred, wrap):
        th = ctx.theme
        out, y = [], 0.0
        counters: dict = {}
        first_para = True
        for para in txb.findall(A("p")):
            ppr = para.find(A("pPr"))
            lvl = min(8, int(ppr.get("lvl", "0"))) if ppr is not None else 0
            pe = [ppr] + ox.lvl_elems(chain, lvl)
            pp = ox.para_props(pe)
            def_elems = [e.find(A("defRPr")) for e in pe if e is not None]

            runs = []
            for ch in para:
                t = ox.local(ch.tag)
                if t == "r":
                    text = ch.findtext(A("t")) or ""
                elif t == "br":
                    text = "\u2028"
                elif t == "fld":
                    text = ch.findtext(A("t")) or ""
                    if ch.get("type", "").startswith("slidenum"):
                        text = str(ctx.index + 1)
                else:
                    continue
                rpr = ch.find(A("rPr"))
                rp = ox.run_props([rpr] + def_elems, th)
                if rpr is not None and rpr.find(A("hlinkClick")) is not None:
                    rp["color"] = th.scheme("hlink") + (255,)
                    rp["u"] = True
                runs.append((text, rp))
            plain = "".join(t for t, _ in runs)
            if runs:
                rp0 = next((rp for t, rp in runs if t.strip()), runs[0][1])
            else:
                rp0 = ox.run_props([para.find(A("endParaRPr"))] + def_elems, th)
            size0 = (rp0["sz"] or DEFAULT_PT) * scale

            # numbering
            bullet = pp["bullet"]
            has_text = bool(plain.strip())
            if bullet and bullet[0] == "auto" and has_text:
                counters[lvl] = counters.get(lvl, bullet[2] - 1) + 1
                for k in [k for k in counters if k > lvl]:
                    del counters[k]
            elif not (bullet and bullet[0] == "auto"):
                for k in [k for k in counters if k >= lvl]:
                    del counters[k]

            marL, indent = pp["marL"] * K, pp["indent"] * K
            bu_info = None
            has_bullet = bool(bullet) and bullet[0] in ("char", "auto") and has_text
            if has_bullet:
                if bullet[0] == "char":
                    bfont, glyph = ox.bullet_glyph(pp["buFont"], bullet[1])
                else:
                    bfont, glyph = pp["buFont"], ox.number_text(bullet[1], counters.get(lvl, 1))
                    if bfont and bfont.lower().startswith(("wingdings", "symbol")):
                        bfont = None
                f = QFont(self._fam(bfont or rp0["font"] or th.minor_font))
                f.setPixelSize(max(1, int(round(size0 * (pp["buSzPct"] or 1.0) * U))))
                f.setHintingPreference(QFont.HintingPreference.PreferNoHinting)
                bc = th.color_in(pp["buClr"])
                color = bc or rp0["color"] or (th.scheme("tx1") + (255,))
                bu_info = {"font": f, "color": color, "text": glyph,
                           "x": marL + indent, "base": 0.0}

            text = plain if plain else " "
            font0 = self._font(rp0, scale, th)
            lay = QTextLayout(text, font0)
            fmts, pos = [], 0
            for t, rp in runs:
                if not t:
                    continue
                fr = QTextLayout.FormatRange()
                fr.start, fr.length = pos, len(t)
                fr.format = self._char_format(rp, scale, th)
                fmts.append(fr)
                pos += len(t)
            if not runs:
                fr = QTextLayout.FormatRange()
                fr.start, fr.length = 0, 1
                fr.format = self._char_format(rp0, scale, th)
                fmts.append(fr)
            lay.setFormats(fmts)
            opt = QTextOption()
            algn = pp["algn"]
            opt.setAlignment({"ctr": Qt.AlignmentFlag.AlignHCenter, "r": Qt.AlignmentFlag.AlignRight,
                              "just": Qt.AlignmentFlag.AlignJustify, "justLow": Qt.AlignmentFlag.AlignJustify,
                              "dist": Qt.AlignmentFlag.AlignJustify}.get(algn, Qt.AlignmentFlag.AlignLeft))
            opt.setWrapMode(QTextOption.WrapMode.WrapAtWordBoundaryOrAnywhere)
            opt.setTabStopDistance(72.0 * U)  # PowerPoint default: 1 inch
            lay.setTextOption(opt)

            if has_bullet:
                x_first = x_rest = marL if indent < 0 else marL + indent + size0 * U * 0.9
            else:
                x_first, x_rest = marL + indent, marL

            # spacing
            def spc(s):
                if not s:
                    return 0.0
                return s[1] * size0 * 1.2 * U if s[0] == "pct" else s[1] * scale * U
            sb = 0.0 if first_para else spc(pp["spcBef"])
            sa = spc(pp["spcAft"])
            ls = pp["lnSpc"]

            lay.beginLayout()
            cy, lines = 0.0, 0
            while True:
                ln = lay.createLine()
                if not ln.isValid():
                    break
                x0 = x_first if lines == 0 else x_rest
                ln.setLineWidth(max(1.0, avail_w - x0) if wrap else 1.0e6)
                nat = ln.height()
                if ls and ls[0] == "pts":
                    lh = max(1.0, ls[1] * scale * U)
                else:
                    lh = nat * max(0.1, (ls[1] if ls else 1.0) - lnred)
                shift = lh - nat
                lx = x0
                if not wrap:
                    free = avail_w - x0 - ln.naturalTextWidth()
                    lx = x0 + free * {"ctr": 0.5, "r": 1.0}.get(algn, 0.0)
                ln.setPosition(QPointF(lx, cy + shift))
                if lines == 0 and bu_info is not None:
                    bu_info["base"] = cy + shift + ln.ascent()
                cy += lh
                lines += 1
            lay.endLayout()

            y += sb
            out.append({"lay": lay, "y": y, "bullet": bu_info})
            y += cy + sa
            first_para = False
        return out, y

    def _font(self, rp, scale, th) -> QFont:
        f = QFont(self._fam(rp["font"] or th.minor_font))
        f.setPixelSize(max(1, int(round((rp["sz"] or DEFAULT_PT) * scale * U))))
        f.setBold(rp["b"])
        f.setItalic(rp["i"])
        f.setUnderline(rp["u"])
        f.setStrikeOut(rp["strike"])
        if rp["cap"] == "all":
            f.setCapitalization(QFont.Capitalization.AllUppercase)
        elif rp["cap"] == "small":
            f.setCapitalization(QFont.Capitalization.SmallCaps)
        if rp["spc"]:
            f.setLetterSpacing(QFont.SpacingType.AbsoluteSpacing, rp["spc"] * U)
        f.setHintingPreference(QFont.HintingPreference.PreferNoHinting)
        f.setStyleStrategy(QFont.StyleStrategy.PreferAntialias)
        return f

    def _char_format(self, rp, scale, th) -> QTextCharFormat:
        fmt = QTextCharFormat()
        fmt.setFont(self._font(rp, scale, th))
        c = rp["color"] or (th.scheme("tx1") + (255,))
        fmt.setForeground(QBrush(QColor(*c)))
        if rp["baseline"] > 0:
            fmt.setVerticalAlignment(QTextCharFormat.VerticalAlignment.AlignSuperScript)
        elif rp["baseline"] < 0:
            fmt.setVerticalAlignment(QTextCharFormat.VerticalAlignment.AlignSubScript)
        return fmt


# ----------------------------------------------------------------------
# Preset geometry library (the shapes decks actually use; others fall back to rect)
# ----------------------------------------------------------------------
def _poly(pts):
    path = QPainterPath()
    path.moveTo(*pts[0])
    for q in pts[1:]:
        path.lineTo(*q)
    path.closeSubpath()
    return path


def _preset(prst, w, h, adj):
    m = min(w, h)
    g = lambda name, d: adj.get(name, d) / 100000.0
    path = QPainterPath()
    if prst in ("line", "straightConnector1"):
        path.moveTo(0, 0)
        path.lineTo(w, h)
        return [(path, False, True)]
    if prst.startswith("bentConnector"):
        path.moveTo(0, 0)
        path.lineTo(w / 2, 0)
        path.lineTo(w / 2, h)
        path.lineTo(w, h)
        return [(path, False, True)]
    if prst.startswith("curvedConnector"):
        path.moveTo(0, 0)
        path.cubicTo(w / 2, 0, w / 2, h, w, h)
        return [(path, False, True)]
    if prst in ("ellipse", "flowChartConnector", "flowChartOr", "flowChartSummingJunction"):
        path.addEllipse(QRectF(0, 0, w, h))
    elif prst in ("roundRect", "flowChartAlternateProcess"):
        r = m * g("adj", 16667)
        path.addRoundedRect(QRectF(0, 0, w, h), r, r)
    elif prst == "triangle":
        path = _poly([(w * g("adj", 50000), 0), (w, h), (0, h)])
    elif prst == "rtTriangle":
        path = _poly([(0, 0), (w, h), (0, h)])
    elif prst in ("diamond", "flowChartDecision"):
        path = _poly([(w / 2, 0), (w, h / 2), (w / 2, h), (0, h / 2)])
    elif prst == "parallelogram":
        o = m * g("adj", 25000)
        path = _poly([(o, 0), (w, 0), (w - o, h), (0, h)])
    elif prst == "trapezoid":
        o = m * g("adj", 25000)
        path = _poly([(o, 0), (w - o, 0), (w, h), (0, h)])
    elif prst == "hexagon":
        o = m * g("adj", 25000)
        path = _poly([(o, 0), (w - o, 0), (w, h / 2), (w - o, h), (o, h), (0, h / 2)])
    elif prst == "octagon":
        o = m * g("adj", 29289)
        path = _poly([(o, 0), (w - o, 0), (w, o), (w, h - o), (w - o, h), (o, h), (0, h - o), (0, o)])
    elif prst == "pentagon":
        path = _poly([(w / 2, 0), (w, h * 0.38), (w * 0.81, h), (w * 0.19, h), (0, h * 0.38)])
    elif prst == "homePlate":
        o = m * g("adj", 50000)
        path = _poly([(0, 0), (w - o, 0), (w, h / 2), (w - o, h), (0, h)])
    elif prst == "chevron":
        o = m * g("adj", 50000)
        path = _poly([(0, 0), (w - o, 0), (w, h / 2), (w - o, h), (0, h), (o, h / 2)])
    elif prst in ("rightArrow", "leftArrow"):
        t, hl = h * g("adj1", 50000), m * g("adj2", 50000)
        y0 = (h - t) / 2
        pts = [(0, y0), (w - hl, y0), (w - hl, 0), (w, h / 2), (w - hl, h), (w - hl, h - y0), (0, h - y0)]
        if prst == "leftArrow":
            pts = [(w - x, y) for x, y in pts]
        path = _poly(pts)
    elif prst in ("upArrow", "downArrow"):
        t, hl = w * g("adj1", 50000), m * g("adj2", 50000)
        x0 = (w - t) / 2
        pts = [(x0, h), (x0, hl), (0, hl), (w / 2, 0), (w, hl), (w - x0, hl), (w - x0, h)]
        if prst == "downArrow":
            pts = [(x, h - y) for x, y in pts]
        path = _poly(pts)
    elif prst in ("plus", "mathPlus"):
        o = m * g("adj", 25000)
        path = _poly([(o, 0), (w - o, 0), (w - o, o), (w, o), (w, h - o), (w - o, h - o),
                      (w - o, h), (o, h), (o, h - o), (0, h - o), (0, o), (o, o)])
    elif prst == "star5":
        pts = []
        for i in range(10):
            ang = -math.pi / 2 + i * math.pi / 5
            rr = 0.5 if i % 2 == 0 else 0.2
            pts.append((w / 2 + math.cos(ang) * w * rr, h / 2 + math.sin(ang) * h * rr))
        path = _poly(pts)
    elif prst == "donut":
        t = m * g("adj", 25000)
        path.addEllipse(QRectF(0, 0, w, h))
        path.addEllipse(QRectF(t, t, max(1, w - 2 * t), max(1, h - 2 * t)))
        path.setFillRule(Qt.FillRule.OddEvenFill)
    else:  # rect, text boxes, and every preset we don't draw specially
        path.addRect(QRectF(0, 0, w, h))
    return [(path, True, True)]


# ----------------------------------------------------------------------
# Render cache + background prefetch
# ----------------------------------------------------------------------
class RenderEngine:
    """LRU image cache bounded by bytes, plus a separate never-evicted thumbnail store.
    One worker thread renders prefetch requests first, thumbnails only when idle."""

    THUMB_W = 420

    def __init__(self, deck: Deck, budget_bytes: int = 320 * 1024 * 1024):
        self.deck = deck
        self.budget = budget_bytes
        self._cache: OrderedDict = OrderedDict()
        self._thumbs: dict = {}
        self._bytes = 0
        self._cl = threading.Lock()
        self._pending: deque = deque()
        self._thumb_todo: deque = deque()
        self._cv = threading.Condition()
        self._stop = False
        self._t = threading.Thread(target=self._run, name="binslide-prefetch", daemon=True)
        self._t.start()

    def get(self, index: int, width: int) -> QImage:
        key = (index, int(width))
        with self._cl:
            img = self._cache.get(key)
            if img is not None:
                self._cache.move_to_end(key)
                return img
        img = self.deck.render(index, width)
        self._store(key, img)
        return img

    def cached(self, index: int, width: int) -> bool:
        with self._cl:
            return (index, int(width)) in self._cache

    def thumb(self, index: int):
        return self._thumbs.get(index)

    def _store(self, key, img):
        with self._cl:
            if key in self._cache:
                return
            self._cache[key] = img
            self._bytes += img.sizeInBytes()
            while self._bytes > self.budget and len(self._cache) > 6:
                _, old = self._cache.popitem(last=False)
                self._bytes -= old.sizeInBytes()

    def prefetch(self, items):
        """Replace the pending prefetch list with [(index, width), ...]."""
        with self._cv:
            self._pending = deque(items)
            self._cv.notify()

    def request_thumbs(self, order):
        """Render thumbnails for the slide indices in ``order`` (idle time only)."""
        with self._cv:
            self._thumb_todo = deque(i for i in order if i not in self._thumbs)
            self._cv.notify()

    def _run(self):
        while True:
            job = None
            with self._cv:
                while not self._pending and not self._thumb_todo and not self._stop:
                    self._cv.wait()
                if self._stop:
                    return
                if self._pending:
                    job = ("full",) + self._pending.popleft()
                else:
                    job = ("thumb", self._thumb_todo.popleft(), self.THUMB_W)
            kind, idx, wid = job
            try:
                if kind == "full":
                    if 0 <= idx < self.deck.count and not self.cached(idx, wid):
                        self._store((idx, int(wid)), self.deck.render(idx, wid))
                elif idx not in self._thumbs:
                    self._thumbs[idx] = self.deck.render(idx, wid)
            except Exception:
                pass

    def shutdown(self):
        with self._cv:
            self._stop = True
            self._cv.notify()
