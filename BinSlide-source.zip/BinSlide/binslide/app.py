"""BinSlide entry point: file picking, multi-monitor layout, input handling."""
from __future__ import annotations

import os
import sys
import threading

from PySide6.QtCore import QEvent, QObject, QStandardPaths, QTimer, QUrl, Qt
from PySide6.QtGui import QColor, QGuiApplication
from PySide6.QtWidgets import QApplication, QFileDialog, QMessageBox

from . import footprint
from .views import PresenterWindow, ProjectorWindow

K = Qt.Key
NEXT_KEYS = {K.Key_Right, K.Key_Down, K.Key_PageDown, K.Key_Space, K.Key_N}
GRID_NAV_KEYS = {K.Key_Left, K.Key_Right, K.Key_Up, K.Key_Down, K.Key_PageUp, K.Key_PageDown,
                 K.Key_Home, K.Key_End}
PREV_KEYS = {K.Key_Left, K.Key_Up, K.Key_PageUp, K.Key_P}
BLACK_KEYS = {K.Key_B, K.Key_Period}
WHITE_KEYS = {K.Key_W, K.Key_Comma}
MAX_JUMP_DIGITS = 4


class Controller(QObject):
    def __init__(self, app, engine):
        super().__init__()
        self.app, self.engine = app, engine
        self.deck = engine.deck
        self.n = self.deck.count
        self.i = 0
        self.buf = ""
        self.cover = None  # None | "black" | "white"
        self.swap = False
        self.esc_armed = False
        self.grid_open = False

        self.proj = ProjectorWindow()
        self.pres = PresenterWindow(self.n, self.deck.aspect)
        self.proj.closed.connect(app.quit)
        self.pres.closed.connect(app.quit)
        self.pres.prevClicked.connect(self.prev)
        self.pres.nextClicked.connect(self.next)
        self.pres.blackToggled.connect(lambda: self.toggle_cover("black"))
        self.pres.endClicked.connect(app.quit)
        self.pres.gridToggled.connect(self.toggle_grid)
        self.pres.grid.picked.connect(self.go)
        self._thumb_timer = QTimer(self)
        self._thumb_timer.timeout.connect(self._poll_thumbs)
        self.proj.canvas.leftClicked.connect(self.next)
        self.proj.canvas.rightClicked.connect(self.prev)

        self._refresh_timer = QTimer(self)
        self._refresh_timer.setSingleShot(True)
        self._refresh_timer.timeout.connect(self.refresh)
        for c in (self.proj.canvas, self.pres.prv, self.pres.cur, self.pres.nxt):
            c.resized.connect(self.schedule_refresh)

        self._layout_timer = QTimer(self)
        self._layout_timer.setSingleShot(True)
        self._layout_timer.timeout.connect(self.relayout)
        app.screenAdded.connect(lambda *_: self._layout_timer.start(400))
        app.screenRemoved.connect(lambda *_: self._layout_timer.start(400))
        app.installEventFilter(self)

        self.relayout()

    # -- screens ---------------------------------------------------------------
    def relayout(self):
        screens = QGuiApplication.screens()
        primary = QGuiApplication.primaryScreen()
        others = [s for s in screens if s is not primary]
        if others:
            proj_s, pres_s = (others[0], primary) if not self.swap else (primary, others[0])
            self._place(self.proj, proj_s, fullscreen=True)
            self._place(self.pres, pres_s, fullscreen=False)
        else:
            self.pres.hide()
            self._place(self.proj, primary, fullscreen=True)
        self.schedule_refresh()

    @staticmethod
    def _place(win, screen, fullscreen):
        win.hide()
        win.setScreen(screen)
        if fullscreen:
            win.setGeometry(screen.geometry())
            win.showFullScreen()
        else:
            win.setGeometry(screen.availableGeometry())
            win.showMaximized()
        win.raise_()

    def toggle_presenter_single(self):
        """With only one monitor: Tab flips between the slide and the presenter view."""
        if len(QGuiApplication.screens()) > 1:
            return
        if self.pres.isVisible():
            self.pres.hide()
            self.proj.showFullScreen()
        else:
            self.pres.showFullScreen()
            self.pres.raise_()
            self.pres.activateWindow()
        self.schedule_refresh()

    # -- rendering ----------------------------------------------------------------
    def schedule_refresh(self):
        self._refresh_timer.start(60)

    def refresh(self, animate=False):
        eng, aspect, i, n = self.engine, self.deck.aspect, self.i, self.n
        widths = []
        if self.proj.isVisible():
            pw = self.proj.canvas.target_px(aspect)
            self.proj.canvas.set_image(eng.get(i, pw), animate)
            widths.append(pw)
        if self.pres.isVisible():
            cw = self.pres.cur.target_px(aspect)
            sw = min(self.pres.prv.target_px(aspect), self.pres.nxt.target_px(aspect))
            self.pres.cur.set_image(eng.get(i, cw))
            if i + 1 < n:
                self.pres.nxt.set_image(eng.get(i + 1, sw))
            else:
                self.pres.nxt.set_message("End of presentation")
            if i > 0:
                self.pres.prv.set_image(eng.get(i - 1, sw))
            else:
                self.pres.prv.set_message("Start of presentation")
            widths += [cw, sw]
        self.pres.set_position(i)
        self.pres.set_black(self.cover == "black")
        errs = self.deck.errors.get(i)
        if errs:
            self.pres.flash("Slide %d: %d item(s) couldn't be drawn (%s)" % (i + 1, len(errs), errs[0][:70]), 6000)
        uniq = list(dict.fromkeys(widths))
        todo = []
        for off in (0, 1, -1, 2, -2, 3):
            j = i + off
            if 0 <= j < n:
                todo += [(j, w) for w in uniq]
        eng.prefetch(todo)

    # -- navigation ----------------------------------------------------------------------
    def go(self, index):
        index = max(0, min(self.n - 1, index))
        if self.grid_open:
            self.close_grid()
        had_cover = self.cover is not None
        if had_cover:
            self.set_cover(None)
        if index != self.i or had_cover:
            changed = index != self.i
            self.i = index
            self.refresh(animate=changed)

    def next(self):
        self.go(self.i + 1)

    def prev(self):
        self.go(self.i - 1)

    def set_cover(self, which):
        self.cover = which
        self.proj.canvas.set_cover({"black": QColor(0, 0, 0), "white": QColor(255, 255, 255)}.get(which))
        self.pres.set_black(which == "black")

    def toggle_cover(self, which):
        self.set_cover(None if self.cover == which else which)

    # -- grid (slide sorter) ---------------------------------------------------------------
    def toggle_grid(self):
        if self.grid_open:
            self.close_grid()
        else:
            self.open_grid()

    def open_grid(self):
        if not self.pres.isVisible():
            self.toggle_presenter_single()      # one monitor: bring the presenter screen up
        if not self.pres.isVisible():
            return
        self.grid_open = True
        self.pres.show_grid(True)
        self.pres.grid.select(self.i)
        self.engine.request_thumbs(sorted(range(self.n), key=lambda j: abs(j - self.i)))
        self._thumb_timer.start(100)
        self._poll_thumbs()

    def close_grid(self):
        if not self.grid_open:
            return
        self.grid_open = False
        self._thumb_timer.stop()
        self.pres.show_grid(False)
        if len(QGuiApplication.screens()) == 1:  # one monitor: back to the full-screen slide
            self.pres.hide()
            self.proj.showFullScreen()
        self.schedule_refresh()

    def _poll_thumbs(self):
        grid = self.pres.grid
        for j in grid.missing():
            t = self.engine.thumb(j)
            if t is not None:
                grid.set_thumb(j, t)
        if not grid.missing():
            self._thumb_timer.stop()

    # -- quick jump --------------------------------------------------------------------------
    def _set_buf(self, text):
        self.buf = text
        self.pres.set_jump(text)

    def _commit_jump(self):
        if self.buf:
            n = int(self.buf)
            self._set_buf("")
            if n >= 1:
                self.go(min(n, self.n) - 1)

    # -- keyboard (app-wide, so it works whichever window has focus) ----------------------------
    def eventFilter(self, obj, ev):
        if ev.type() == QEvent.Type.KeyPress and self._on_key(ev):
            return True
        return False

    def _on_key(self, ev) -> bool:
        key = ev.key()
        mods = ev.modifiers()
        if mods & (Qt.KeyboardModifier.ControlModifier | Qt.KeyboardModifier.AltModifier
                   | Qt.KeyboardModifier.MetaModifier):
            return False  # leave Alt+F4, Win+..., etc. alone

        if K.Key_0 <= key <= K.Key_9:
            if not ev.isAutoRepeat() and len(self.buf) < MAX_JUMP_DIGITS:
                self._set_buf(self.buf + chr(key))
            return True
        if self.grid_open:
            if key == K.Key_Escape:
                if self.buf:
                    self._set_buf("")
                else:
                    self.close_grid()
                return True
            if key == K.Key_G:
                self.close_grid()
                return True
            if key in (K.Key_Return, K.Key_Enter, K.Key_Space):
                if self.buf:
                    self._commit_jump()
                else:
                    row = self.pres.grid.currentRow()
                    self.go(row if row >= 0 else self.i)
                return True
            if key in GRID_NAV_KEYS:
                return False                      # let the grid move its own selection
            if key == K.Key_Backspace:
                self._set_buf(self.buf[:-1])
                return True
        if key in (K.Key_Return, K.Key_Enter):
            if self.buf:
                self._commit_jump()
            else:
                self.next()
            return True
        if key == K.Key_Escape:
            if self.buf:
                self._set_buf("")
            elif self.esc_armed:
                self.app.quit()
            else:
                self.esc_armed = True
                self.pres.flash("Press Esc again to exit")
                QTimer.singleShot(1600, lambda: setattr(self, "esc_armed", False))
            return True
        if key == K.Key_Backspace:
            if self.buf:
                self._set_buf(self.buf[:-1])
            else:
                self.prev()
            return True
        if key in NEXT_KEYS:
            self.next()
        elif key in PREV_KEYS:
            self.prev()
        elif key == K.Key_Home:
            self.go(0)
        elif key == K.Key_End:
            self.go(self.n - 1)
        elif key in BLACK_KEYS:
            self.toggle_cover("black")
        elif key in WHITE_KEYS:
            self.toggle_cover("white")
        elif key == K.Key_G:
            self.toggle_grid()
        elif key == K.Key_Tab:
            self.toggle_presenter_single()
        elif key == K.Key_S:
            self.swap = not self.swap
            self.relayout()
        else:
            return False
        return True


# ----------------------------------------------------------------------
def pick_file():
    """Qt's own dialog: the native Windows one records an MRU list in the registry."""
    dlg = QFileDialog(None, "BinSlide — choose a presentation")
    dlg.setOption(QFileDialog.Option.DontUseNativeDialog, True)
    dlg.setFileMode(QFileDialog.FileMode.ExistingFile)
    dlg.setNameFilters(["PowerPoint presentations (*.pptx)", "All files (*)"])
    dlg.setViewMode(QFileDialog.ViewMode.Detail)
    SP = QStandardPaths.StandardLocation
    dirs = [QStandardPaths.writableLocation(x) for x in (SP.DesktopLocation, SP.DownloadLocation, SP.DocumentsLocation)]
    dirs = [d for d in dirs if d and os.path.isdir(d)]
    from PySide6.QtCore import QDir
    dlg.setSidebarUrls([QUrl.fromLocalFile(d) for d in dirs]
                       + [QUrl.fromLocalFile(i.absoluteFilePath()) for i in QDir.drives()])
    if dirs:
        dlg.setDirectory(dirs[0])
    dlg.resize(900, 560)
    if dlg.exec() and dlg.selectedFiles():
        return dlg.selectedFiles()[0]
    return None


def _preimport():
    try:
        import pptx  # noqa: F401  (warm the import while the user is choosing a file)
        import lxml.etree  # noqa: F401
        import PIL.Image  # noqa: F401
    except Exception:
        pass


def main() -> int:
    footprint.hold_marker()
    footprint.cleanup_stale_runtime()
    footprint.confine_qt_settings()
    threading.Thread(target=_preimport, daemon=True).start()

    app = QApplication(sys.argv)
    app.setApplicationName("BinSlide")
    app.setStyle("Fusion")

    footprint.load_extra_fonts()
    from .renderer import Deck, RenderEngine

    path = next((a for a in sys.argv[1:] if a.lower().endswith(".pptx") and os.path.isfile(a)), None)
    deck = None
    while deck is None:
        path = path or pick_file()
        if not path:
            return 0
        try:
            with open(path, "rb") as f:
                data = f.read()          # whole file into RAM; handle closed immediately
            deck = Deck(data)
            del data
            if deck.count == 0:
                raise ValueError("The presentation has no slides.")
        except Exception as exc:
            QMessageBox.critical(None, "BinSlide",
                                 "Could not open this file:\n%s\n\nOnly .pptx files are supported." % exc)
            deck, path = None, None

    notes = []
    if deck.warnings:
        lines = ["  Slide %d: %s" % (k, ", ".join(sorted(v))) for k, v in sorted(deck.warnings.items())]
        notes.append("These can't be drawn and will appear as a labelled box:\n" + "\n".join(lines[:10])
                     + ("\n  …" if len(lines) > 10 else ""))
    missing = deck.font_report()
    if missing:
        notes.append("Fonts not installed on this PC: %s.\nSimilar fonts will be substituted, so text may "
                     "wrap differently. To fix, put the .ttf/.otf files in a folder named \"fonts\" "
                     "next to BinSlide.exe." % ", ".join(missing[:8]) + (" …" if len(missing) > 8 else ""))
    if notes:
        box = QMessageBox(QMessageBox.Icon.Warning, "BinSlide", "\n\n".join(notes))
        go = box.addButton("Present anyway", QMessageBox.ButtonRole.AcceptRole)
        box.addButton("Cancel", QMessageBox.ButtonRole.RejectRole)
        box.exec()
        if box.clickedButton() is not go:
            return 0

    engine = RenderEngine(deck)
    ctrl = Controller(app, engine)  # noqa: F841  (kept alive by the event loop)
    rc = app.exec()
    engine.shutdown()
    return rc
