"""
Qt-free OOXML helpers: theme colours, fill/line style tables and the
text-style inheritance chain (shape -> layout -> master -> txStyles -> defaults).

Everything here is pure data resolution so it can be unit-tested without a GUI.
"""
from __future__ import annotations

import colorsys
from lxml import etree

A_NS = "http://schemas.openxmlformats.org/drawingml/2006/main"
P_NS = "http://schemas.openxmlformats.org/presentationml/2006/main"
R_NS = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
NS = {"a": A_NS, "p": P_NS, "r": R_NS}

EMU_PER_PT = 12700.0
# Painting coordinate system: 1 pt == U units. Qt font pixel sizes must be ints,
# so working in 1/8 pt gives font sizes a resolution of 0.125 pt.
U = 8.0
EMU_TO_U = U / EMU_PER_PT


def A(tag: str) -> str:
    return "{%s}%s" % (A_NS, tag)


def P(tag: str) -> str:
    return "{%s}%s" % (P_NS, tag)


def local(tag) -> str:
    return etree.QName(tag).localname if isinstance(tag, str) else ""


Color = tuple  # (r, g, b, a) all 0..255

_PRESET = {
    "black": (0, 0, 0), "white": (255, 255, 255), "red": (255, 0, 0),
    "green": (0, 128, 0), "blue": (0, 0, 255), "yellow": (255, 255, 0),
    "gray": (128, 128, 128), "grey": (128, 128, 128), "orange": (255, 165, 0),
    "purple": (128, 0, 128), "cyan": (0, 255, 255), "magenta": (255, 0, 255),
    "dkGray": (169, 169, 169), "ltGray": (211, 211, 211),
}
_SYS = {"windowText": (0, 0, 0), "window": (255, 255, 255)}
COLOR_TAGS = ("srgbClr", "schemeClr", "sysClr", "prstClr", "scrgbClr", "hslClr")


def _clamp(v):
    return max(0, min(255, int(round(v))))


class Theme:
    """Colour scheme, font scheme and format scheme of one slide master."""

    def __init__(self, theme_root, clrmap_attrs: dict):
        self.colors: dict[str, tuple] = {}
        self.clrmap = dict(clrmap_attrs or {})
        self.major_font = "Calibri Light"
        self.minor_font = "Calibri"
        self.fills: list = []
        self.bg_fills: list = []
        self.lines: list = []
        if theme_root is None:
            self.colors = {"dk1": (0, 0, 0), "lt1": (255, 255, 255)}
            return
        cs = theme_root.find(".//a:clrScheme", NS)
        if cs is not None:
            for ch in cs:
                inner = next(iter(ch), None)
                if inner is None:
                    continue
                t = local(inner.tag)
                if t == "srgbClr":
                    self.colors[local(ch.tag)] = _hex(inner.get("val"))
                elif t == "sysClr":
                    self.colors[local(ch.tag)] = _hex(inner.get("lastClr", "000000"))
        for key, attr in (("major", "major_font"), ("minor", "minor_font")):
            lat = theme_root.find(".//a:fontScheme/a:%sFont/a:latin" % key, NS)
            if lat is not None and lat.get("typeface"):
                setattr(self, attr, lat.get("typeface"))
        fs = theme_root.find(".//a:fmtScheme", NS)
        if fs is not None:
            def kids(tag):
                el = fs.find(tag, NS)
                return list(el) if el is not None else []
            self.fills = kids("a:fillStyleLst")
            self.bg_fills = kids("a:bgFillStyleLst")
            self.lines = kids("a:lnStyleLst")

    # -- colours ---------------------------------------------------------
    def scheme(self, name: str) -> tuple:
        name = self.clrmap.get(name, name)
        return self.colors.get(name, (0, 0, 0))

    def resolve(self, el, ph=None) -> Color:
        """Resolve a colour element (srgbClr, schemeClr, ...) to (r,g,b,a)."""
        tag = local(el.tag)
        val = el.get("val")
        if tag == "srgbClr":
            rgb = _hex(val)
        elif tag == "schemeClr":
            rgb = (ph or (0, 0, 0)) if val == "phClr" else self.scheme(val)
        elif tag == "sysClr":
            rgb = _hex(el.get("lastClr")) if el.get("lastClr") else _SYS.get(val, (0, 0, 0))
        elif tag == "prstClr":
            rgb = _PRESET.get(val, (0, 0, 0))
        else:
            rgb = (0, 0, 0)
        r, g, b = rgb[0], rgb[1], rgb[2]
        alpha = 255.0
        for mod in el:
            t = local(mod.tag)
            try:
                v = int(mod.get("val", "0"))
            except ValueError:
                continue
            if t in ("lumMod", "lumOff", "satMod", "satOff"):
                h, l, s = colorsys.rgb_to_hls(r / 255, g / 255, b / 255)
                f = v / 100000.0
                if t == "lumMod":
                    l *= f
                elif t == "lumOff":
                    l += f
                elif t == "satMod":
                    s *= f
                else:
                    s += f
                l = min(1.0, max(0.0, l))
                s = min(1.0, max(0.0, s))
                r, g, b = (c * 255 for c in colorsys.hls_to_rgb(h, l, s))
            elif t == "tint":
                f = v / 100000.0
                r, g, b = (c * f + 255 * (1 - f) for c in (r, g, b))
            elif t == "shade":
                f = v / 100000.0
                r, g, b = (c * f for c in (r, g, b))
            elif t == "alpha":
                alpha = v / 100000.0 * 255
            elif t == "alphaMod":
                alpha *= v / 100000.0
        return (_clamp(r), _clamp(g), _clamp(b), _clamp(alpha))

    def color_in(self, parent, ph=None):
        """First colour child of ``parent`` resolved, or None."""
        if parent is None:
            return None
        for ch in parent:
            if local(ch.tag) in COLOR_TAGS:
                return self.resolve(ch, ph)
        return None

    def font(self, typeface: str | None) -> str | None:
        if not typeface:
            return None
        if typeface == "+mj-lt":
            return self.major_font
        if typeface == "+mn-lt":
            return self.minor_font
        if typeface.startswith("+"):
            return None
        return typeface

    # -- format scheme ---------------------------------------------------
    def fill_style(self, idx: int):
        if idx >= 1001:
            lst, i = self.bg_fills, idx - 1001
        else:
            lst, i = self.fills, idx - 1
        return lst[i] if 0 <= i < len(lst) else None

    def line_style(self, idx: int):
        i = idx - 1
        return self.lines[i] if 0 <= i < len(self.lines) else None


def _hex(val) -> tuple:
    try:
        v = (val or "000000").lstrip("#")
        return (int(v[0:2], 16), int(v[2:4], 16), int(v[4:6], 16))
    except Exception:
        return (0, 0, 0)


# ----------------------------------------------------------------------
# Text style inheritance
# ----------------------------------------------------------------------
def lvl_elems(chain, lvl: int):
    """The ``a:lvl{n}pPr`` element from every lstStyle-like element in chain."""
    tag = A("lvl%dpPr" % (lvl + 1))
    out = []
    for el in chain:
        if el is None:
            continue
        c = el.find(tag)
        if c is not None:
            out.append(c)
    return out


def first_attr(elems, name):
    for e in elems:
        if e is not None and e.get(name) is not None:
            return e.get(name)
    return None


def _spacing(elems, tag):
    """Returns ('pct', fraction) / ('pts', points) / None."""
    for e in elems:
        if e is None:
            continue
        c = e.find(A(tag))
        if c is None:
            continue
        pct = c.find(A("spcPct"))
        if pct is not None:
            return ("pct", int(pct.get("val", "100000")) / 100000.0)
        pts = c.find(A("spcPts"))
        if pts is not None:
            return ("pts", int(pts.get("val", "0")) / 100.0)
    return None


def para_props(ppr_elems) -> dict:
    """Merge paragraph-level props from [paragraph pPr, lvlNpPr from chain...]."""
    d = {
        "algn": first_attr(ppr_elems, "algn") or "l",
        "marL": int(first_attr(ppr_elems, "marL") or 0),
        "indent": int(first_attr(ppr_elems, "indent") or 0),
        "lnSpc": _spacing(ppr_elems, "lnSpc"),
        "spcBef": _spacing(ppr_elems, "spcBef"),
        "spcAft": _spacing(ppr_elems, "spcAft"),
        "bullet": None, "buFont": None, "buClr": None, "buSzPct": None,
    }
    for e in ppr_elems:
        if e is None:
            continue
        if d["bullet"] is None:
            if e.find(A("buNone")) is not None:
                d["bullet"] = ("none",)
            else:
                ch = e.find(A("buChar"))
                if ch is not None:
                    d["bullet"] = ("char", ch.get("char", "•"))
                else:
                    an = e.find(A("buAutoNum"))
                    if an is not None:
                        d["bullet"] = ("auto", an.get("type", "arabicPeriod"),
                                       int(an.get("startAt", "1")))
        if d["buFont"] is None:
            f = e.find(A("buFont"))
            if f is not None:
                d["buFont"] = f.get("typeface")
        if d["buClr"] is None:
            c = e.find(A("buClr"))
            if c is not None:
                d["buClr"] = c
        if d["buSzPct"] is None:
            s = e.find(A("buSzPct"))
            if s is not None:
                d["buSzPct"] = int(s.get("val", "100000")) / 100000.0
    return d


def run_props(rpr_elems, theme: Theme, ph_color=None) -> dict:
    """Merge run props from [rPr, defRPr-from-paragraph, defRPr from chain...]."""
    def attr(n):
        return first_attr(rpr_elems, n)

    typeface = None
    color = None
    for e in rpr_elems:
        if e is None:
            continue
        if typeface is None:
            lat = e.find(A("latin"))
            if lat is not None and lat.get("typeface"):
                typeface = lat.get("typeface")
        if color is None:
            sf = e.find(A("solidFill"))
            if sf is not None:
                color = theme.color_in(sf, ph_color)
        if typeface and color:
            break
    sz = attr("sz")
    return {
        "sz": int(sz) / 100.0 if sz else None,
        "b": attr("b") in ("1", "true"),
        "i": attr("i") in ("1", "true"),
        "u": (attr("u") or "none") != "none",
        "strike": (attr("strike") or "noStrike") != "noStrike",
        "cap": attr("cap") or "none",
        "spc": int(attr("spc") or 0) / 100.0,
        "baseline": int(attr("baseline") or 0),
        "font": theme.font(typeface),
        "color": color,
    }


def make_defrpr(bold=None, color=None):
    """Synthetic lstStyle (all 9 levels) carrying one defRPr; used to inject
    shape-style font colours and table-style header text."""
    holder = etree.Element(A("lstStyle"))
    for lvl in range(1, 10):
        wrapper = etree.SubElement(holder, A("lvl%dpPr" % lvl))
        el = etree.SubElement(wrapper, A("defRPr"))
        if bold is not None:
            el.set("b", "1" if bold else "0")
        if color is not None:
            sf = etree.SubElement(el, A("solidFill"))
            c = etree.SubElement(sf, A("srgbClr"))
            c.set("val", "%02X%02X%02X" % tuple(color[:3]))
    return holder


def number_text(kind: str, n: int) -> str:
    def alpha(k, upper):
        s = ""
        while k > 0:
            k, r = divmod(k - 1, 26)
            s = chr(97 + r) + s
        return s.upper() if upper else s

    def roman(k, upper):
        vals = [(1000, "m"), (900, "cm"), (500, "d"), (400, "cd"), (100, "c"), (90, "xc"),
                (50, "l"), (40, "xl"), (10, "x"), (9, "ix"), (5, "v"), (4, "iv"), (1, "i")]
        s = ""
        for v, t in vals:
            while k >= v:
                s += t
                k -= v
        return s.upper() if upper else s

    if kind.startswith("alphaLc"):
        core = alpha(n, False)
    elif kind.startswith("alphaUc"):
        core = alpha(n, True)
    elif kind.startswith("romanLc"):
        core = roman(n, False)
    elif kind.startswith("romanUc"):
        core = roman(n, True)
    else:
        core = str(n)
    if kind.endswith("ParenBoth"):
        return "(%s)" % core
    if kind.endswith("ParenR"):
        return "%s)" % core
    return "%s." % core


# Wingdings/Symbol bullet glyphs commonly seen in templates -> Unicode.
BULLET_MAP = {
    ("Wingdings", "§"): "▪", ("Wingdings", "Ø"): "➢", ("Wingdings", "ü"): "✓",
    ("Wingdings", "v"): "❖", ("Wingdings", "l"): "●", ("Wingdings", "n"): "■",
    ("Wingdings", "q"): "❑", ("Wingdings", "u"): "◆", ("Wingdings", "¡"): "○",
    ("Symbol", "·"): "•", ("Wingdings 3", "}"): "▶",
}


def bullet_glyph(font: str | None, ch: str) -> tuple:
    """Returns (font_or_None, glyph)."""
    if font and (font, ch) in BULLET_MAP:
        return None, BULLET_MAP[(font, ch)]
    if font and font.lower().startswith(("wingdings", "symbol", "webdings")):
        return None, "•"
    return font, ch
