"""Widgets: SlideCanvas (draws one pre-rendered slide), ProjectorWindow, PresenterWindow."""
from __future__ import annotations

from PySide6.QtCore import QSize, Qt, QEasingCurve, QRectF, QTimer, QVariantAnimation, Signal
from PySide6.QtGui import QColor, QFont, QIcon, QPainter, QPixmap
from PySide6.QtWidgets import (
    QHBoxLayout, QLabel, QListView, QListWidget, QListWidgetItem, QPushButton, QSizePolicy,
    QStackedWidget, QVBoxLayout, QWidget,
)

FADE_MS = 140  # projector cross-fade; cancelled instantly by the next key press


class SlideCanvas(QWidget):
    """Draws a ready-made QImage letterboxed and pixel-exact. No scaling at paint time."""

    leftClicked = Signal()
    rightClicked = Signal()
    resized = Signal()

    def __init__(self, bg=QColor(0, 0, 0), fade_ms=0, parent=None):
        super().__init__(parent)
        self._bg = bg
        self._img = None
        self._prev = None
        self._cover = None
        self._message = None
        self._t = 1.0
        self._anim = QVariantAnimation(self)
        self._anim.setStartValue(0.0)
        self._anim.setEndValue(1.0)
        self._anim.setDuration(fade_ms)
        self._anim.setEasingCurve(QEasingCurve.Type.OutCubic)
        self._anim.valueChanged.connect(self._tick)
        self._anim.finished.connect(self._done)
        self._fade = fade_ms > 0
        self.setAttribute(Qt.WidgetAttribute.WA_OpaquePaintEvent)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        self.setMinimumSize(160, 90)

    # -- sizing ---------------------------------------------------------
    def target_px(self, aspect: float) -> int:
        """Pixel width of the largest slide image that fits this widget."""
        dpr = self.devicePixelRatioF()
        W, H = self.width() * dpr, self.height() * dpr
        return int(max(2, min(W, H * aspect)))

    # -- state ------------------------------------------------------------
    def set_image(self, img, animate=False):
        self._message = None
        if self._fade and animate and self._img is not None and img is not None \
                and self._img.size() == img.size() and self._cover is None:
            self._prev = self._img
            self._img = img
            self._t = 0.0
            self._anim.stop()
            self._anim.start()
        else:
            self._anim.stop()
            self._prev = None
            self._t = 1.0
            self._img = img
        self.update()

    def set_message(self, text):
        self._anim.stop()
        self._img, self._prev, self._message = None, None, text
        self.update()

    def set_cover(self, color):
        self._cover = color
        self.update()

    def _tick(self, v):
        self._t = float(v)
        self.update()

    def _done(self):
        self._prev = None
        self._t = 1.0
        self.update()

    # -- events ---------------------------------------------------------------
    def paintEvent(self, _ev):
        p = QPainter(self)
        p.fillRect(self.rect(), self._bg)
        if self._cover is not None:
            p.fillRect(self.rect(), self._cover)
            return
        if self._message:
            p.setPen(QColor(120, 128, 140))
            f = QFont(self.font())
            f.setPointSize(16)
            p.setFont(f)
            p.drawText(self.rect(), Qt.AlignmentFlag.AlignCenter, self._message)
            return
        if self._img is None:
            return
        dpr = self.devicePixelRatioF()
        iw, ih = self._img.width(), self._img.height()
        x = round((self.width() * dpr - iw) / 2.0) / dpr
        y = round((self.height() * dpr - ih) / 2.0) / dpr
        dst = QRectF(x, y, iw / dpr, ih / dpr)
        if self._prev is not None and self._t < 1.0:
            p.drawImage(dst, self._prev)
            p.setOpacity(self._t)
        p.drawImage(dst, self._img)

    def resizeEvent(self, ev):
        super().resizeEvent(ev)
        self.resized.emit()

    def mousePressEvent(self, ev):
        if ev.button() == Qt.MouseButton.LeftButton:
            self.leftClicked.emit()
        elif ev.button() == Qt.MouseButton.RightButton:
            self.rightClicked.emit()


class ProjectorWindow(QWidget):
    """Borderless full-screen slide only. No toolbars, no cursor."""

    closed = Signal()

    def __init__(self):
        super().__init__()
        self.setWindowTitle("BinSlide")
        self.setWindowFlags(Qt.WindowType.FramelessWindowHint | Qt.WindowType.Window)
        self.setStyleSheet("background:#000;")
        self.setCursor(Qt.CursorShape.BlankCursor)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        self.canvas = SlideCanvas(QColor(0, 0, 0), fade_ms=FADE_MS)
        lay.addWidget(self.canvas)

    def closeEvent(self, ev):
        self.closed.emit()
        ev.accept()


_PRESENTER_CSS = """
QWidget#root { background:#14161a; }
QLabel { color:#e6e9ef; }
QLabel#caption { color:#8a93a3; font-size:12px; font-weight:600; letter-spacing:2px; }
QLabel#counter { font-size:30px; font-weight:700; padding:0 14px; }
QLabel#jump { color:#8a93a3; font-size:15px; }
QLabel#jump[active="true"] { color:#ffd166; font-size:22px; font-weight:700; }
QLabel#status { color:#ff9f6e; font-size:14px; }
QPushButton { background:#262b33; color:#e6e9ef; border:none; border-radius:8px;
              padding:12px 22px; font-size:16px; font-weight:600; }
QPushButton:hover { background:#323945; }
QPushButton:pressed { background:#3d4655; }
QPushButton:checked { background:#ffd166; color:#14161a; }
QPushButton#end { background:#4a2428; }
QPushButton#end:hover { background:#6b2f35; }
QListWidget { background:#14161a; border:none; color:#c9cfda; font-size:14px; outline:0; }
QListWidget::item { padding:6px; border-radius:8px; }
QListWidget::item:hover { background:#262b33; }
QListWidget::item:selected { background:#ffd166; color:#14161a; }
"""

GRID_ICON_W = 280


class SlideGrid(QListWidget):
    """Slide sorter: every slide as a thumbnail; click (or arrows + Enter) to jump."""

    picked = Signal(int)

    def __init__(self, count: int, aspect: float):
        super().__init__()
        self._count = count
        self._have = set()
        iw = GRID_ICON_W
        ih = int(round(iw / aspect))
        self.setViewMode(QListView.ViewMode.IconMode)
        self.setResizeMode(QListView.ResizeMode.Adjust)
        self.setMovement(QListView.Movement.Static)
        self.setUniformItemSizes(True)
        self.setWrapping(True)
        self.setSpacing(12)
        self.setIconSize(QSize(iw, ih))
        self.setVerticalScrollMode(QListWidget.ScrollMode.ScrollPerPixel)
        placeholder = QPixmap(iw, ih)
        placeholder.fill(QColor(38, 43, 51))
        icon = QIcon(placeholder)
        for i in range(count):
            it = QListWidgetItem(icon, str(i + 1))
            it.setTextAlignment(Qt.AlignmentFlag.AlignHCenter)
            self.addItem(it)
        self.itemClicked.connect(lambda it: self.picked.emit(self.row(it)))
        self.itemActivated.connect(lambda it: self.picked.emit(self.row(it)))

    def set_thumb(self, index: int, img):
        self._have.add(index)
        self.item(index).setIcon(QIcon(QPixmap.fromImage(img)))

    def missing(self):
        return [i for i in range(self._count) if i not in self._have]

    def select(self, index: int):
        self.setCurrentRow(index)
        self.scrollToItem(self.item(index), QListWidget.ScrollHint.PositionAtCenter)


class PresenterWindow(QWidget):
    """Previous | Current | Next, big remote-friendly controls, and a slide-sorter page."""

    closed = Signal()
    prevClicked = Signal()
    nextClicked = Signal()
    blackToggled = Signal()
    gridToggled = Signal()
    endClicked = Signal()

    def __init__(self, total: int, aspect: float):
        super().__init__()
        self.setObjectName("root")
        self.setWindowTitle("BinSlide — Presenter")
        self.setStyleSheet(_PRESENTER_CSS)
        self._total = total

        bg = QColor(20, 22, 26)
        self.prv = SlideCanvas(bg)
        self.cur = SlideCanvas(bg)
        self.nxt = SlideCanvas(bg)

        def column(caption, canvas):
            box = QVBoxLayout()
            box.setSpacing(8)
            lab = QLabel(caption)
            lab.setObjectName("caption")
            box.addWidget(lab)
            box.addWidget(canvas, 1)
            return box

        slides_page = QWidget()
        top = QHBoxLayout(slides_page)
        top.setContentsMargins(0, 0, 0, 0)
        top.setSpacing(16)
        # Current is the biggest; previous and next share one size (so they share one render).
        top.addLayout(column("PREVIOUS", self.prv), 2)
        top.addLayout(column("CURRENT", self.cur), 3)
        top.addLayout(column("NEXT", self.nxt), 2)

        self.grid = SlideGrid(total, aspect)
        self.stack = QStackedWidget()
        self.stack.addWidget(slides_page)
        self.stack.addWidget(self.grid)

        self.btn_prev = self._button("◀  Prev")
        self.btn_next = self._button("Next  ▶")
        self.btn_grid = self._button("Grid (G)")
        self.btn_grid.setCheckable(True)
        self.btn_black = self._button("Black (B)")
        self.btn_black.setCheckable(True)
        self.btn_end = self._button("End show")
        self.btn_end.setObjectName("end")
        self.counter = QLabel()
        self.counter.setObjectName("counter")
        self.jump = QLabel()
        self.jump.setObjectName("jump")
        self.status = QLabel()
        self.status.setObjectName("status")

        bar = QHBoxLayout()
        bar.setSpacing(12)
        for w in (self.btn_prev, self.counter, self.btn_next):
            bar.addWidget(w)
        bar.addSpacing(24)
        bar.addWidget(self.jump)
        bar.addStretch(1)
        bar.addWidget(self.status)
        bar.addSpacing(12)
        bar.addWidget(self.btn_grid)
        bar.addWidget(self.btn_black)
        bar.addWidget(self.btn_end)

        root = QVBoxLayout(self)
        root.setContentsMargins(24, 20, 24, 20)
        root.setSpacing(16)
        root.addWidget(self.stack, 1)
        root.addLayout(bar)

        self.btn_prev.clicked.connect(self.prevClicked)
        self.btn_next.clicked.connect(self.nextClicked)
        self.btn_grid.clicked.connect(self.gridToggled)
        self.btn_black.clicked.connect(self.blackToggled)
        self.btn_end.clicked.connect(self.endClicked)
        self.cur.leftClicked.connect(self.nextClicked)
        self.nxt.leftClicked.connect(self.nextClicked)
        self.prv.leftClicked.connect(self.prevClicked)

        self._status_timer = QTimer(self)
        self._status_timer.setSingleShot(True)
        self._status_timer.timeout.connect(lambda: self.status.setText(""))
        self.set_position(0)
        self.set_jump("")

    def _button(self, text):
        b = QPushButton(text)
        b.setFocusPolicy(Qt.FocusPolicy.NoFocus)  # Space/Enter must never "click" a button
        b.setCursor(Qt.CursorShape.PointingHandCursor)
        return b

    def show_grid(self, on: bool):
        self.stack.setCurrentIndex(1 if on else 0)
        self.btn_grid.setChecked(on)
        if on:
            self.grid.setFocus()

    def grid_visible(self) -> bool:
        return self.stack.currentIndex() == 1

    def set_position(self, index: int):
        self.counter.setText("%d / %d" % (index + 1, self._total))

    def set_jump(self, digits: str):
        if digits:
            self.jump.setText("Go to slide  %s▌    Enter ↵ jump · Esc cancel" % digits)
        else:
            self.jump.setText("Type a number, then Enter, to jump")
        self.jump.setProperty("active", bool(digits))
        self.jump.style().unpolish(self.jump)
        self.jump.style().polish(self.jump)

    def set_black(self, on: bool):
        self.btn_black.setChecked(on)

    def flash(self, text: str, ms=2400):
        self.status.setText(text)
        self._status_timer.start(ms)

    def closeEvent(self, ev):
        self.closed.emit()
        ev.accept()
