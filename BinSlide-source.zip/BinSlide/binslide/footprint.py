"""Best-effort zero-footprint helpers (no Qt widgets here; safe to import first)."""
from __future__ import annotations

import atexit
import os
import shutil
import sys
import tempfile

MARKER = "binslide.marker"
_marker_handle = None  # held open for the life of the process (see below)


def frozen() -> bool:
    return bool(getattr(sys, "frozen", False)) and hasattr(sys, "_MEIPASS")


def runtime_dir() -> str:
    """A directory that is deleted when the app exits."""
    if frozen():
        return sys._MEIPASS
    d = tempfile.mkdtemp(prefix="binslide_")
    atexit.register(shutil.rmtree, d, True)
    return d


def hold_marker():
    """Keep our marker file open: Windows then refuses to delete it, which is how a
    second BinSlide tells 'orphaned by a yanked USB' from 'still running'."""
    global _marker_handle
    if frozen():
        try:
            _marker_handle = open(os.path.join(sys._MEIPASS, MARKER), "rb")
        except OSError:
            pass


def cleanup_stale_runtime():
    """PyInstaller one-file unpacks to %TEMP%\\_MEIxxxxxx and removes it on a normal exit.
    If the stick was pulled / the process killed, that folder is orphaned. Sweep any
    earlier BinSlide leftovers (recognised by the marker file) that no process holds."""
    if not frozen():
        return
    tmp = os.environ.get("TEMP") or tempfile.gettempdir()
    mine = os.path.normcase(os.path.abspath(sys._MEIPASS))
    try:
        names = os.listdir(tmp)
    except OSError:
        return
    for name in names:
        if not name.startswith("_MEI"):
            continue
        d = os.path.join(tmp, name)
        if os.path.normcase(os.path.abspath(d)) == mine:
            continue
        marker = os.path.join(d, MARKER)
        if not os.path.exists(marker):
            continue
        try:
            os.remove(marker)  # fails while another BinSlide still has it open
        except OSError:
            continue
        shutil.rmtree(d, ignore_errors=True)


def confine_qt_settings():
    """Qt's non-native file dialog persists its history via QSettings (registry on
    Windows). Redirect QSettings into the throw-away runtime directory instead."""
    from PySide6.QtCore import QSettings
    base = os.path.join(runtime_dir(), "qs")
    os.makedirs(base, exist_ok=True)
    QSettings.setDefaultFormat(QSettings.Format.IniFormat)
    for scope in (QSettings.Scope.UserScope, QSettings.Scope.SystemScope):
        QSettings.setPath(QSettings.Format.IniFormat, scope, base)


def load_extra_fonts() -> int:
    """Register .ttf/.otf/.ttc files for THIS process only (nothing is installed in Windows).
    Looks in a `fonts` folder next to BinSlide.exe and in `bundled_fonts` inside the exe."""
    from PySide6.QtCore import QByteArray
    from PySide6.QtGui import QFontDatabase
    dirs = []
    if frozen():
        dirs.append(os.path.join(sys._MEIPASS, "bundled_fonts"))
        dirs.append(os.path.join(os.path.dirname(os.path.abspath(sys.executable)), "fonts"))
    else:
        root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        dirs += [os.path.join(root, "bundled_fonts"), os.path.join(root, "fonts")]
    n = 0
    for d in dirs:
        if not os.path.isdir(d):
            continue
        for name in sorted(os.listdir(d)):
            if name.lower().endswith((".ttf", ".otf", ".ttc")):
                try:
                    with open(os.path.join(d, name), "rb") as f:
                        data = f.read()
                    if QFontDatabase.addApplicationFontFromData(QByteArray(data)) >= 0:
                        n += 1
                except OSError:
                    pass
    return n
